
@php
    $booking = $booking ?? null;
    $selectedCustomer = old('customer_id', $booking?->customer_id);
    $selectedBusinessUnit = old('business_unit_id', $booking?->business_unit_id);
    $quantity = old('quantity', $booking?->quantity ?? 1);
    $unitPrice = old('unit_price', $booking?->unit_price ?? 0);
    $amountPaid = old('amount_paid', $booking?->amount_paid ?? 0);
@endphp

<div class="space-y-8">

    <section>
        <div class="mb-5 border-b border-slate-200 pb-3">
            <h3 class="font-bold text-slate-900">Informasi Pelanggan & Unit Bisnis</h3>
            <p class="mt-1 text-sm text-slate-500">
                Tentukan pelanggan dan unit bisnis yang menerima pesanan.
            </p>
        </div>

        <div class="grid gap-5 md:grid-cols-2">

            <div>
                <label for="customer_id" class="mb-2 block text-sm font-semibold">
                    Pelanggan <span class="text-red-500">*</span>
                </label>

                <select name="customer_id" id="customer_id" required
                        class="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 focus:border-indigo-500">
                    <option value="">Pilih pelanggan</option>

                    @foreach($customers as $customer)
                        <option value="{{ $customer->id }}"
                            @selected((string) $selectedCustomer === (string) $customer->id)>
                            {{ $customer->name }}
                            @if($customer->company_name)
                                — {{ $customer->company_name }}
                            @endif
                        </option>
                    @endforeach
                </select>

                @error('customer_id')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror

                @if($customers->isEmpty())
                    <p class="mt-2 text-sm text-red-600">
                        Belum ada pelanggan aktif.
                        <a href="{{ route('customers.create') }}" class="font-semibold underline">
                            Tambahkan pelanggan
                        </a>
                    </p>
                @endif
            </div>

            <div>
                <label for="business_unit_id" class="mb-2 block text-sm font-semibold">
                    Unit Bisnis <span class="text-red-500">*</span>
                </label>

                <select name="business_unit_id" id="business_unit_id" required
                        class="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 focus:border-indigo-500">
                    <option value="">Pilih unit bisnis</option>

                    @foreach($businessUnits as $unit)
                        <option value="{{ $unit->id }}"
                            @selected((string) $selectedBusinessUnit === (string) $unit->id)>
                            {{ $unit->name }}
                        </option>
                    @endforeach
                </select>

                @error('business_unit_id')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror

                @if($businessUnits->isEmpty())
                    <p class="mt-2 text-sm text-red-600">
                        Belum ada unit bisnis aktif. Periksa pengaturan Business Units.
                    </p>
                @endif
            </div>

        </div>
    </section>

    <section>
        <div class="mb-5 border-b border-slate-200 pb-3">
            <h3 class="font-bold text-slate-900">Detail Pesanan</h3>
            <p class="mt-1 text-sm text-slate-500">
                Informasi jasa, produk, atau layanan yang dipesan.
            </p>
        </div>

        <div class="space-y-5">

            <div>
                <label for="title" class="mb-2 block text-sm font-semibold">
                    Nama Pesanan <span class="text-red-500">*</span>
                </label>

                <input type="text" name="title" id="title" required maxlength="255"
                       value="{{ old('title', $booking?->title) }}"
                       placeholder="Contoh: Sound System untuk Wedding Event"
                       class="w-full rounded-xl border border-slate-300 px-4 py-3 focus:border-indigo-500">

                @error('title')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="description" class="mb-2 block text-sm font-semibold">
                    Deskripsi Pesanan
                </label>

                <textarea name="description" id="description" rows="3"
                          placeholder="Jelaskan detail jasa atau produk yang dipesan..."
                          class="w-full rounded-xl border border-slate-300 px-4 py-3 focus:border-indigo-500">{{ old('description', $booking?->description) }}</textarea>

                @error('description')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div class="grid gap-5 md:grid-cols-2">
                <div>
                    <label for="event_date" class="mb-2 block text-sm font-semibold">
                        Tanggal Pelaksanaan
                    </label>

                    <input type="date" name="event_date" id="event_date"
                           value="{{ old('event_date', $booking?->event_date?->format('Y-m-d')) }}"
                           class="w-full rounded-xl border border-slate-300 px-4 py-3 focus:border-indigo-500">

                    @error('event_date')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="location" class="mb-2 block text-sm font-semibold">
                        Lokasi / Alamat
                    </label>

                    <input type="text" name="location" id="location"
                           value="{{ old('location', $booking?->location) }}"
                           placeholder="Lokasi kegiatan atau pengiriman"
                           class="w-full rounded-xl border border-slate-300 px-4 py-3 focus:border-indigo-500">

                    @error('location')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            </div>

        </div>
    </section>

    <section>
        <div class="mb-5 border-b border-slate-200 pb-3">
            <h3 class="font-bold text-slate-900">Rincian Harga</h3>
            <p class="mt-1 text-sm text-slate-500">
                Total pesanan dihitung dari jumlah dikalikan harga satuan.
            </p>
        </div>

        <div class="grid gap-5 md:grid-cols-2">

            <div>
                <label for="quantity" class="mb-2 block text-sm font-semibold">
                    Jumlah / Kuantitas <span class="text-red-500">*</span>
                </label>

                <input type="number" name="quantity" id="quantity" min="1" step="1" required
                       value="{{ $quantity }}"
                       class="w-full rounded-xl border border-slate-300 px-4 py-3 focus:border-indigo-500">

                @error('quantity')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="unit_price" class="mb-2 block text-sm font-semibold">
                    Harga Satuan (Rp) <span class="text-red-500">*</span>
                </label>

                <input type="number" name="unit_price" id="unit_price"
                       min="0" step="0.01" required
                       value="{{ $unitPrice }}"
                       class="w-full rounded-xl border border-slate-300 px-4 py-3 focus:border-indigo-500">

                @error('unit_price')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div class="rounded-xl border border-indigo-100 bg-indigo-50 p-5 md:col-span-2">
                <p class="text-sm font-medium text-indigo-700">Estimasi Total Pesanan</p>
                <p id="totalPreview" class="mt-2 text-3xl font-bold text-indigo-900">
                    Rp0
                </p>
                <p class="mt-2 text-xs text-indigo-600">
                    Total = Jumlah × Harga Satuan. Nilai final dihitung ulang oleh server.
                </p>
            </div>

            <div class="md:col-span-2">
                <label for="amount_paid" class="mb-2 block text-sm font-semibold">
                    Pembayaran Diterima (Rp)
                </label>

                <input type="number" name="amount_paid" id="amount_paid"
                       min="0" step="0.01"
                       value="{{ $amountPaid }}"
                       class="w-full rounded-xl border border-slate-300 px-4 py-3 focus:border-indigo-500">

                @error('amount_paid')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror

                <p class="mt-2 text-xs text-slate-500">
                    Status pembayaran akan ditentukan otomatis berdasarkan jumlah pembayaran.
                </p>
            </div>

        </div>
    </section>

    <section>
        <div class="mb-5 border-b border-slate-200 pb-3">
            <h3 class="font-bold text-slate-900">Status & Catatan</h3>
            <p class="mt-1 text-sm text-slate-500">
                Atur progres pengerjaan pesanan.
            </p>
        </div>

        <div class="space-y-5">

            <div>
                <label for="booking_status" class="mb-2 block text-sm font-semibold">
                    Status Pesanan <span class="text-red-500">*</span>
                </label>

                <select name="booking_status" id="booking_status" required
                        class="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 focus:border-indigo-500">
                    <option value="pending" @selected(old('booking_status', $booking?->booking_status ?? 'pending') === 'pending')>
                        Pending — Menunggu
                    </option>
                    <option value="confirmed" @selected(old('booking_status', $booking?->booking_status) === 'confirmed')>
                        Confirmed — Dikonfirmasi
                    </option>
                    <option value="in_progress" @selected(old('booking_status', $booking?->booking_status) === 'in_progress')>
                        In Progress — Sedang Dikerjakan
                    </option>
                    <option value="completed" @selected(old('booking_status', $booking?->booking_status) === 'completed')>
                        Completed — Selesai
                    </option>
                    <option value="cancelled" @selected(old('booking_status', $booking?->booking_status) === 'cancelled')>
                        Cancelled — Dibatalkan
                    </option>
                </select>

                @error('booking_status')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="notes" class="mb-2 block text-sm font-semibold">
                    Catatan Internal
                </label>

                <textarea name="notes" id="notes" rows="4"
                          placeholder="Catatan tambahan untuk tim SIGAPRODUCTION..."
                          class="w-full rounded-xl border border-slate-300 px-4 py-3 focus:border-indigo-500">{{ old('notes', $booking?->notes) }}</textarea>

                @error('notes')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

        </div>
    </section>

</div>

<div class="mt-8 flex flex-col-reverse gap-3 border-t border-slate-200 pt-6 sm:flex-row sm:justify-end">
    <a href="{{ route('bookings.index') }}"
       class="rounded-xl border border-slate-300 px-6 py-3 text-center font-semibold text-slate-600 hover:bg-slate-50">
        Batal
    </a>

    <button type="submit"
            @disabled($customers->isEmpty() || $businessUnits->isEmpty())
            class="rounded-xl bg-indigo-600 px-6 py-3 font-semibold text-white hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50">
        {{ $submitLabel }}
    </button>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const quantityInput = document.getElementById('quantity');
    const priceInput = document.getElementById('unit_price');
    const totalPreview = document.getElementById('totalPreview');

    function updateTotal() {
        const quantity = Math.max(0, Number(quantityInput.value) || 0);
        const price = Math.max(0, Number(priceInput.value) || 0);
        const total = quantity * price;

        totalPreview.textContent = new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            maximumFractionDigits: 0
        }).format(total);
    }

    quantityInput.addEventListener('input', updateTotal);
    priceInput.addEventListener('input', updateTotal);

    updateTotal();
});
</script>
